-- ============================================================
-- SUPABASE SCHEMA — Plataforma SaaS Postventa Automotriz
-- Versión 1.0 — Marzo 2026
-- Ejecutar en orden. RLS activo en todas las tablas.
-- ============================================================

-- ── EXTENSIONES ──────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── ENUMS ────────────────────────────────────────────────────

CREATE TYPE tipo_cliente AS ENUM ('particular', 'empresa', 'flotilla');
CREATE TYPE canal_preferido AS ENUM ('whatsapp', 'email', 'llamada', 'presencial');
CREATE TYPE estado_cita AS ENUM ('pendiente_contactar', 'contactada', 'confirmada', 'show', 'no_show', 'cancelada');
CREATE TYPE fuente_cita AS ENUM ('salesforce', 'seekop', 'clearmechanic', 'drive', 'manual', 'bot', 'web');
CREATE TYPE estado_ot AS ENUM ('recibido', 'diagnostico', 'en_reparacion', 'listo', 'entregado', 'cancelado');
CREATE TYPE estado_pieza AS ENUM ('pendiente', 'pedida', 'en_transito', 'recibida', 'instalada');
CREATE TYPE estado_cotizacion AS ENUM ('borrador', 'enviada', 'abierta', 'aprobada', 'rechazada', 'vencida');
CREATE TYPE estado_lead AS ENUM ('nuevo', 'contactado', 'cotizado', 'negociando', 'cerrado_ganado', 'cerrado_perdido');
CREATE TYPE tipo_actividad AS ENUM ('llamada', 'contacto', 'seguimiento', 'tarea', 'reunion', 'recordatorio', 'cita_agendada', 'cotizacion_enviada', 'wa_enviado', 'csi_enviado');
CREATE TYPE estado_actividad AS ENUM ('pendiente', 'en_proceso', 'realizada', 'cancelada');
CREATE TYPE prioridad_actividad AS ENUM ('normal', 'alta', 'urgente');
CREATE TYPE modulo_origen AS ENUM ('crm', 'citas', 'taller', 'refacciones', 'ventas', 'bandeja', 'ia', 'sistema');
CREATE TYPE canal_mensaje AS ENUM ('whatsapp', 'facebook', 'instagram', 'email', 'interno');
CREATE TYPE condicion_csi AS ENUM ('feliz', 'no_feliz', 'sin_evaluar');
CREATE TYPE estado_venta_perdida AS ENUM ('detectada', 'registrada', 'contacto_enviado', 'cliente_interesado', 'cita_agendada', 'cerrada', 'sin_recuperar');
CREATE TYPE rol_usuario AS ENUM ('admin', 'gerente', 'asesor_servicio', 'asesor_ventas', 'encargada_citas', 'mk_atencion', 'refacciones', 'key_user', 'viewer');

-- ── SUCURSALES ────────────────────────────────────────────────
CREATE TABLE sucursales (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  nombre TEXT NOT NULL,
  marca TEXT,                              -- KIA, Toyota, VW, etc.
  direccion TEXT,
  maps_url TEXT,                           -- link Google Maps para WA de confirmaciones
  maps_embed_url TEXT,
  telefono TEXT,
  whatsapp TEXT,
  horario_bot_inicio TIME DEFAULT '08:00', -- hora de inicio del bot
  horario_bot_fin TIME DEFAULT '19:30',    -- hora de fin del bot (7:30 PM)
  timezone TEXT DEFAULT 'America/Mexico_City',
  activa BOOLEAN DEFAULT TRUE,
  creada_at TIMESTAMPTZ DEFAULT NOW(),
  actualizada_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── USUARIOS ──────────────────────────────────────────────────
CREATE TABLE usuarios (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  nombre TEXT NOT NULL,
  apellido TEXT,
  email TEXT UNIQUE NOT NULL,
  telefono TEXT,
  whatsapp TEXT,
  rol rol_usuario DEFAULT 'asesor_servicio',
  outlook_refresh_token TEXT,              -- para Outlook Calendar sync
  outlook_calendar_id TEXT,
  activo BOOLEAN DEFAULT TRUE,
  creado_at TIMESTAMPTZ DEFAULT NOW(),
  actualizado_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── EMPRESAS ──────────────────────────────────────────────────
CREATE TABLE empresas (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  razon_social TEXT NOT NULL,
  nombre_comercial TEXT,
  rfc TEXT,
  email TEXT,
  telefono TEXT,
  whatsapp TEXT,
  direccion TEXT,
  contacto_nombre TEXT,
  contacto_cargo TEXT,
  notas TEXT,
  creada_at TIMESTAMPTZ DEFAULT NOW(),
  actualizada_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── CLIENTES ──────────────────────────────────────────────────
CREATE TABLE clientes (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  empresa_id UUID REFERENCES empresas(id),    -- null si es particular
  nombre TEXT NOT NULL,
  apellido TEXT,
  email TEXT,
  whatsapp TEXT NOT NULL,                     -- campo clave para deduplicación + WA
  telefono_alterno TEXT,
  tipo tipo_cliente DEFAULT 'particular',
  canal_preferido canal_preferido DEFAULT 'whatsapp',
  rfc TEXT,
  id_dms TEXT,                                -- ID en Autoline u otro DMS
  asesor_asignado_id UUID REFERENCES usuarios(id),
  notas TEXT,
  activo BOOLEAN DEFAULT TRUE,
  creado_at TIMESTAMPTZ DEFAULT NOW(),
  actualizado_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(sucursal_id, whatsapp)               -- no duplicar por sucursal + WA
);

-- ── VEHÍCULOS ─────────────────────────────────────────────────
CREATE TABLE vehiculos (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  cliente_id UUID REFERENCES clientes(id) ON DELETE CASCADE NOT NULL,
  sucursal_id UUID REFERENCES sucursales(id),
  vin TEXT,                                   -- campo clave para deduplicación
  placa TEXT,
  marca TEXT,
  modelo TEXT,
  anio INTEGER,
  version TEXT,
  color TEXT,
  km_actuales INTEGER,
  km_garantia INTEGER,
  fecha_compra DATE,
  fecha_fin_garantia DATE,
  numero_motor TEXT,
  id_dms TEXT,
  notas TEXT,
  creado_at TIMESTAMPTZ DEFAULT NOW(),
  actualizado_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(vin)                                 -- VIN único global
);

-- ── CITAS ─────────────────────────────────────────────────────
CREATE TABLE citas (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  cliente_id UUID REFERENCES clientes(id),
  vehiculo_id UUID REFERENCES vehiculos(id),
  asesor_id UUID REFERENCES usuarios(id),
  encargada_citas_id UUID REFERENCES usuarios(id), -- encargada asignada para el contacto
  
  fecha_cita TIMESTAMPTZ NOT NULL,
  tipo_servicio TEXT,
  observaciones TEXT,
  
  -- Estado del Kanban
  estado estado_cita DEFAULT 'pendiente_contactar',
  fuente fuente_cita DEFAULT 'manual',
  
  -- Control del contacto (flujo de 15 minutos)
  contacto_asignado_at TIMESTAMPTZ,           -- cuando se asignó el contacto
  contacto_limite_at TIMESTAMPTZ,             -- contacto_asignado_at + 15 min
  contacto_realizado_at TIMESTAMPTZ,
  contacto_realizado_por UUID REFERENCES usuarios(id), -- null si lo hizo el bot
  contacto_bot BOOLEAN DEFAULT FALSE,         -- true si el bot actuó por la encargada
  
  -- Recordatorios
  recordatorio_24h_enviado_at TIMESTAMPTZ,
  recordatorio_2h_enviado_at TIMESTAMPTZ,
  confirmacion_cliente BOOLEAN,               -- true = confirmó, false = rechazó
  confirmacion_at TIMESTAMPTZ,
  
  -- No-show
  no_show_registrado_at TIMESTAMPTZ,
  recuperacion_wa_enviado_at TIMESTAMPTZ,
  
  -- Metadatos del archivo origen
  archivo_origen TEXT,                        -- nombre del archivo que originó esta cita
  id_externo TEXT,                            -- ID en el sistema externo (SF, Seekop, etc.)
  
  creada_at TIMESTAMPTZ DEFAULT NOW(),
  actualizada_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── ÓRDENES DE TRABAJO (OT / PDV) ─────────────────────────────
CREATE TABLE ordenes_trabajo (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  cliente_id UUID REFERENCES clientes(id),
  vehiculo_id UUID REFERENCES vehiculos(id),
  cita_id UUID REFERENCES citas(id),
  asesor_id UUID REFERENCES usuarios(id),
  
  numero_ot TEXT UNIQUE NOT NULL,
  fecha_recepcion TIMESTAMPTZ DEFAULT NOW(),
  km_entrada INTEGER,
  promesa_entrega TIMESTAMPTZ,
  fecha_entrega TIMESTAMPTZ,
  
  estado estado_ot DEFAULT 'recibido',
  
  -- Seguimiento
  ultima_actualizacion_at TIMESTAMPTZ,
  horas_sin_actualizar INTEGER,              -- calculado por trigger
  nivel_escalacion INTEGER DEFAULT 0,        -- 0=normal, 1=alerta_asesor, 2=alerta_gerente, 3=bot_actuo
  
  -- Link de seguimiento público
  token_seguimiento TEXT UNIQUE DEFAULT encode(gen_random_bytes(16), 'hex'),
  
  -- CSI
  condicion_csi condicion_csi DEFAULT 'sin_evaluar',
  csi_calificacion INTEGER,                  -- 1-10
  csi_enviado_at TIMESTAMPTZ,
  csi_respondido_at TIMESTAMPTZ,
  resena_google_solicitada BOOLEAN DEFAULT FALSE,
  
  -- Firma digital
  firma_digital_url TEXT,
  firma_digital_at TIMESTAMPTZ,
  
  total_mano_obra DECIMAL(10,2),
  total_refacciones DECIMAL(10,2),
  total_ot DECIMAL(10,2),
  
  notas_internas TEXT,
  creada_at TIMESTAMPTZ DEFAULT NOW(),
  actualizada_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── PIEZAS / EXPEDIENTE DE PIEZA ──────────────────────────────
CREATE TABLE piezas_ot (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  ot_id UUID REFERENCES ordenes_trabajo(id) ON DELETE CASCADE,
  sucursal_id UUID REFERENCES sucursales(id),
  cliente_id UUID REFERENCES clientes(id),
  
  numero_parte TEXT,
  descripcion TEXT NOT NULL,
  cantidad INTEGER DEFAULT 1,
  proveedor TEXT,
  eta DATE,                                  -- fecha estimada de llegada
  
  estado estado_pieza DEFAULT 'pendiente',
  fecha_pedido TIMESTAMPTZ,
  fecha_llegada TIMESTAMPTZ,
  
  costo_unitario DECIMAL(10,2),
  imagen_oem_url TEXT,                       -- imagen del portal de la marca
  
  -- Seguimiento de notificaciones al cliente
  ultimo_wa_enviado_at TIMESTAMPTZ,
  wa_llegada_enviado BOOLEAN DEFAULT FALSE,  -- ya se envió el WA de "pieza llegó"
  cliente_respondio_agendar BOOLEAN,         -- true si el cliente tocó "Sí, agendar"
  cliente_respondio_at TIMESTAMPTZ,
  
  creada_at TIMESTAMPTZ DEFAULT NOW(),
  actualizada_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── VENTAS PERDIDAS ───────────────────────────────────────────
CREATE TABLE ventas_perdidas (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  cliente_id UUID REFERENCES clientes(id),
  vehiculo_id UUID REFERENCES vehiculos(id),
  ot_id UUID REFERENCES ordenes_trabajo(id),
  asesor_id UUID REFERENCES usuarios(id),
  
  descripcion_reparacion TEXT NOT NULL,
  monto_rechazado DECIMAL(10,2),
  fecha_rechazo TIMESTAMPTZ NOT NULL,
  
  estado estado_venta_perdida DEFAULT 'detectada',
  
  -- Seguimiento de recuperación
  contacto_wa_enviado_at TIMESTAMPTZ,
  contacto_wa_respuesta_at TIMESTAMPTZ,
  cliente_interesado BOOLEAN,
  
  -- Cuando el cliente quiere agendar
  actividad_citas_id UUID,                   -- FK a actividades (la que se crea para la encargada)
  cita_recuperacion_id UUID REFERENCES citas(id),
  
  notas TEXT,
  creada_at TIMESTAMPTZ DEFAULT NOW(),
  actualizada_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── COTIZACIONES DE REFACCIONES ────────────────────────────────
CREATE TABLE cotizaciones (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  cliente_id UUID REFERENCES clientes(id),
  vehiculo_id UUID REFERENCES vehiculos(id),
  asesor_id UUID REFERENCES usuarios(id),
  ot_id UUID REFERENCES ordenes_trabajo(id),
  
  numero_cotizacion TEXT UNIQUE,
  estado estado_cotizacion DEFAULT 'borrador',
  fecha_emision TIMESTAMPTZ DEFAULT NOW(),
  fecha_vencimiento TIMESTAMPTZ,
  
  total DECIMAL(10,2),
  moneda TEXT DEFAULT 'MXN',
  
  pdf_url TEXT,
  
  -- Tracking de apertura
  enviada_at TIMESTAMPTZ,
  abierta_at TIMESTAMPTZ,
  abierta_por_cliente BOOLEAN DEFAULT FALSE,
  
  -- Seguimiento bot
  seguimiento_24h_at TIMESTAMPTZ,
  seguimiento_48h_at TIMESTAMPTZ,
  seguimiento_72h_at TIMESTAMPTZ,           -- si no responde → actividad al asesor
  
  aprobada_at TIMESTAMPTZ,
  rechazada_at TIMESTAMPTZ,
  
  notas TEXT,
  creada_at TIMESTAMPTZ DEFAULT NOW(),
  actualizada_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── ÍTEMS DE COTIZACIÓN ───────────────────────────────────────
CREATE TABLE cotizacion_items (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  cotizacion_id UUID REFERENCES cotizaciones(id) ON DELETE CASCADE,
  numero_parte TEXT,
  descripcion TEXT NOT NULL,
  cantidad INTEGER DEFAULT 1,
  precio_unitario DECIMAL(10,2),
  total DECIMAL(10,2),
  imagen_oem_url TEXT
);

-- ── LEADS / VENTAS PIPELINE ───────────────────────────────────
CREATE TABLE leads (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  cliente_id UUID REFERENCES clientes(id),  -- puede ser null si es lead nuevo
  asesor_id UUID REFERENCES usuarios(id),
  
  nombre TEXT,                              -- si no es cliente aún
  whatsapp TEXT,
  email TEXT,
  
  estado estado_lead DEFAULT 'nuevo',
  fuente canal_mensaje DEFAULT 'whatsapp',
  necesidad TEXT,                           -- servicio | refaccion | venta | info
  
  vehiculo_interes TEXT,                    -- modelo que le interesa comprar
  presupuesto_estimado DECIMAL(10,2),
  
  ultima_interaccion_at TIMESTAMPTZ,
  horas_sin_actualizar INTEGER,
  
  notas TEXT,
  creado_at TIMESTAMPTZ DEFAULT NOW(),
  actualizado_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── ACTIVIDADES (MODELO UNIVERSAL) ────────────────────────────
CREATE TABLE actividades (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  
  -- Tipo y estado
  tipo tipo_actividad NOT NULL,
  titulo TEXT NOT NULL,
  descripcion TEXT,
  estado estado_actividad DEFAULT 'pendiente',
  prioridad prioridad_actividad DEFAULT 'normal',
  
  -- Fechas
  fecha_programada TIMESTAMPTZ,
  fecha_realizada TIMESTAMPTZ,
  
  -- Resultado
  resultado TEXT,
  notas TEXT,
  duracion_minutos INTEGER,
  
  -- Vínculos (toda actividad se vincula a múltiples entidades)
  usuario_asignado_id UUID REFERENCES usuarios(id) NOT NULL,
  creada_por_id UUID REFERENCES usuarios(id),
  cliente_id UUID REFERENCES clientes(id),
  vehiculo_id UUID REFERENCES vehiculos(id),
  empresa_id UUID REFERENCES empresas(id),
  ot_id UUID REFERENCES ordenes_trabajo(id),
  cita_id UUID REFERENCES citas(id),
  cotizacion_id UUID REFERENCES cotizaciones(id),
  lead_id UUID REFERENCES leads(id),
  venta_perdida_id UUID REFERENCES ventas_perdidas(id),
  pieza_ot_id UUID REFERENCES piezas_ot(id),
  
  -- Sync con Outlook
  outlook_event_id TEXT,                    -- ID del evento en Outlook del usuario
  outlook_synced_at TIMESTAMPTZ,
  
  -- Notificaciones enviadas
  wa_enviado BOOLEAN DEFAULT FALSE,
  wa_enviado_at TIMESTAMPTZ,
  email_enviado BOOLEAN DEFAULT FALSE,
  email_enviado_at TIMESTAMPTZ,
  
  -- Módulo que la generó
  modulo_origen modulo_origen DEFAULT 'crm',
  
  creada_at TIMESTAMPTZ DEFAULT NOW(),
  actualizada_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── MENSAJES / BANDEJA UNIFICADA ──────────────────────────────
CREATE TABLE mensajes (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  cliente_id UUID REFERENCES clientes(id),
  usuario_asesor_id UUID REFERENCES usuarios(id), -- asesor asignado
  
  canal canal_mensaje NOT NULL,
  direccion TEXT NOT NULL CHECK (direccion IN ('entrante', 'saliente')),
  contenido TEXT,
  media_url TEXT,
  media_tipo TEXT,                          -- imagen, audio, video, documento
  
  -- Metadatos del proveedor
  id_externo TEXT,                          -- ID del mensaje en WA/Meta/etc.
  estado_entrega TEXT,                      -- enviado, entregado, leido, error
  
  enviado_por_bot BOOLEAN DEFAULT FALSE,
  enviado_at TIMESTAMPTZ DEFAULT NOW(),
  leido_at TIMESTAMPTZ,
  leido_por_asesor BOOLEAN DEFAULT FALSE
);

-- ── ARCHIVOS IMPORTADOS ───────────────────────────────────────
CREATE TABLE archivos_importados (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  usuario_id UUID REFERENCES usuarios(id),
  
  nombre_archivo TEXT,
  tipo TEXT,                                -- citas | ot | csi | venta_perdida | clientes
  fuente TEXT,                              -- drive | csv | excel | autoline | sf | seekop
  
  total_registros INTEGER,
  registros_creados INTEGER,
  registros_actualizados INTEGER,
  registros_con_error INTEGER,
  errores JSONB,
  
  estado TEXT DEFAULT 'procesando',         -- procesando | completado | error
  procesado_at TIMESTAMPTZ,
  creado_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── MAESTRO DE PARTES ─────────────────────────────────────────
CREATE TABLE maestro_partes (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  
  numero_parte TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  marca_vehiculo TEXT,
  imagen_oem_url TEXT,
  precio_lista DECIMAL(10,2),
  disponible BOOLEAN,
  
  -- Origen del dato
  fuente TEXT,                              -- dms | portal_marca | manual
  ultima_consulta_at TIMESTAMPTZ,
  
  UNIQUE(sucursal_id, numero_parte)
);

-- ── NOTIFICACIONES ENCOLADAS ──────────────────────────────────
-- Mensajes que se generan fuera del horario del bot (8am–7:30pm)
-- se guardan aquí y se envían al abrir el siguiente día
CREATE TABLE notificaciones_encoladas (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  sucursal_id UUID REFERENCES sucursales(id),
  cliente_id UUID REFERENCES clientes(id),
  
  tipo TEXT,                                -- wa | email
  destinatario TEXT,                        -- número WA o email
  contenido TEXT,
  media_url TEXT,
  
  contexto_modulo modulo_origen,
  contexto_id UUID,                         -- ID del registro relacionado
  
  programada_at TIMESTAMPTZ DEFAULT NOW(),  -- cuándo se generó el evento
  enviar_at TIMESTAMPTZ,                    -- cuándo enviar (8am del día siguiente)
  enviada_at TIMESTAMPTZ,
  estado TEXT DEFAULT 'encolada'            -- encolada | enviada | error
);

-- ════════════════════════════════════════════════════
-- ÍNDICES PARA PERFORMANCE
-- ════════════════════════════════════════════════════

CREATE INDEX idx_clientes_whatsapp ON clientes(whatsapp);
CREATE INDEX idx_clientes_sucursal ON clientes(sucursal_id);
CREATE INDEX idx_vehiculos_vin ON vehiculos(vin);
CREATE INDEX idx_vehiculos_cliente ON vehiculos(cliente_id);
CREATE INDEX idx_citas_estado ON citas(estado);
CREATE INDEX idx_citas_fecha ON citas(fecha_cita);
CREATE INDEX idx_citas_sucursal_fecha ON citas(sucursal_id, fecha_cita);
CREATE INDEX idx_ot_numero ON ordenes_trabajo(numero_ot);
CREATE INDEX idx_ot_estado ON ordenes_trabajo(estado);
CREATE INDEX idx_ot_token ON ordenes_trabajo(token_seguimiento);
CREATE INDEX idx_actividades_usuario ON actividades(usuario_asignado_id);
CREATE INDEX idx_actividades_cliente ON actividades(cliente_id);
CREATE INDEX idx_actividades_estado ON actividades(estado);
CREATE INDEX idx_actividades_fecha ON actividades(fecha_programada);
CREATE INDEX idx_mensajes_cliente ON mensajes(cliente_id);
CREATE INDEX idx_mensajes_canal ON mensajes(canal);
CREATE INDEX idx_mensajes_asesor ON mensajes(usuario_asesor_id);
CREATE INDEX idx_leads_estado ON leads(estado);
CREATE INDEX idx_ventas_perdidas_estado ON ventas_perdidas(estado);

-- ════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (RLS)
-- ════════════════════════════════════════════════════

ALTER TABLE sucursales ENABLE ROW LEVEL SECURITY;
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE empresas ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehiculos ENABLE ROW LEVEL SECURITY;
ALTER TABLE citas ENABLE ROW LEVEL SECURITY;
ALTER TABLE ordenes_trabajo ENABLE ROW LEVEL SECURITY;
ALTER TABLE piezas_ot ENABLE ROW LEVEL SECURITY;
ALTER TABLE ventas_perdidas ENABLE ROW LEVEL SECURITY;
ALTER TABLE cotizaciones ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE actividades ENABLE ROW LEVEL SECURITY;
ALTER TABLE mensajes ENABLE ROW LEVEL SECURITY;
ALTER TABLE maestro_partes ENABLE ROW LEVEL SECURITY;

-- Política base: usuario solo ve datos de su sucursal
-- (Ajustar según roles en implementación)
CREATE POLICY "usuarios_propia_sucursal" ON clientes
  USING (sucursal_id = (SELECT sucursal_id FROM usuarios WHERE id = auth.uid()));

CREATE POLICY "usuarios_propia_sucursal" ON citas
  USING (sucursal_id = (SELECT sucursal_id FROM usuarios WHERE id = auth.uid()));

CREATE POLICY "usuarios_propia_sucursal" ON ordenes_trabajo
  USING (sucursal_id = (SELECT sucursal_id FROM usuarios WHERE id = auth.uid()));

CREATE POLICY "usuarios_propia_sucursal" ON actividades
  USING (sucursal_id = (SELECT sucursal_id FROM usuarios WHERE id = auth.uid()));

-- Política pública para link de seguimiento de OT (sin auth)
CREATE POLICY "seguimiento_publico" ON ordenes_trabajo
  FOR SELECT USING (token_seguimiento IS NOT NULL);

-- ════════════════════════════════════════════════════
-- FUNCIONES Y TRIGGERS
-- ════════════════════════════════════════════════════

-- Actualizar timestamp automáticamente
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.actualizada_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER t_clientes_updated BEFORE UPDATE ON clientes
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER t_citas_updated BEFORE UPDATE ON citas
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER t_ot_updated BEFORE UPDATE ON ordenes_trabajo
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER t_actividades_updated BEFORE UPDATE ON actividades
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Calcular horas sin actualizar en OT
CREATE OR REPLACE FUNCTION calcular_horas_sin_actualizar()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.ultima_actualizacion_at IS NOT NULL THEN
    NEW.horas_sin_actualizar = EXTRACT(EPOCH FROM (NOW() - NEW.ultima_actualizacion_at)) / 3600;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER t_ot_horas BEFORE UPDATE ON ordenes_trabajo
  FOR EACH ROW EXECUTE FUNCTION calcular_horas_sin_actualizar();

-- Asignar fecha límite del contacto al crear cita (15 minutos)
CREATE OR REPLACE FUNCTION asignar_limite_contacto()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.contacto_asignado_at IS NOT NULL AND NEW.contacto_limite_at IS NULL THEN
    NEW.contacto_limite_at = NEW.contacto_asignado_at + INTERVAL '15 minutes';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER t_citas_limite BEFORE INSERT OR UPDATE ON citas
  FOR EACH ROW EXECUTE FUNCTION asignar_limite_contacto();

