# CLAUDE.md — Instrucciones para Claude Code
## Plataforma SaaS de Gestión de Servicio Postventa Automotriz

Este archivo es la ÚNICA fuente de verdad para Claude Code.
Lee PRODUCT_MASTER.md para el detalle completo del producto.
Lee SUPABASE_SCHEMA.sql para el esquema de base de datos.
Lee TECH_STACK.md para decisiones técnicas.

---

## IDENTIDAD DEL PROYECTO

- **Tipo**: SaaS vertical automotriz (postventa / aftersales)
- **Nombre**: Por definir (cuando el producto esté terminado)
- **Stack**: Next.js 14 + TypeScript + TailwindCSS + Supabase + Claude API + n8n + shadcn/ui + Vercel
- **Dev environment**: GitHub Codespaces o local con Cursor/VSCode
- **DMS piloto**: Autoline
- **Horario del bot**: 8:00 AM – 7:30 PM (mensajes fuera de horario se encolan)

---

## REGLAS DE DESARROLLO

1. **Nunca romper funcionalidad existente** — solo agregar o mejorar
2. **TypeScript estricto** — no usar `any`
3. **Componentes shadcn/ui** como base de UI
4. **TailwindCSS** para estilos — dark theme como predeterminado
5. **Supabase** para todo: auth, BD, storage, edge functions
6. **n8n** para automatizaciones: lectura de archivos, bot WA, CSI, escalaciones
7. **Claude API** para: clasificación de mensajes, sugerencias IA, venta cruzada, guiones de llamada
8. **Cada variable nueva** debe tener comentario inline explicando su propósito
9. **RLS (Row Level Security)** activo en todas las tablas desde el inicio

---

## MÓDULOS Y PRIORIDAD DE DESARROLLO

### Fase 1 — Base técnica (semanas 1-2)
- [ ] Proyecto Next.js 14 con TypeScript y TailwindCSS
- [ ] Supabase: schema completo, RLS, auth
- [ ] Layout principal: sidebar + topbar + content area
- [ ] Módulo CRM: CRUD de clientes, vehículos, empresas

### Fase 2 — CITAS (semanas 3-5)
- [ ] Lector de archivos (Drive / CSV / Excel → CRM)
- [ ] Vista Kanban de citas con 5 columnas
- [ ] Timer de 15 minutos por cita pendiente
- [ ] Integración n8n: WA de confirmación + mapa Google Maps
- [ ] Agenda de la encargada con Outlook sync

### Fase 3 — TALLER + WhatsApp (semanas 6-9)
- [ ] CRUD de OTs con estados
- [ ] Link de seguimiento público (sin login)
- [ ] Bot WA activo: recordatorios, estados, CSI
- [ ] Flujo pieza pendiente + notificación encargada
- [ ] Escalación automática 3 niveles

### Fase 4 — REFACCIONES + BANDEJA (semanas 10-13)
- [ ] Maestro de partes + scraping portal marca
- [ ] Generación PDF con imagen OEM
- [ ] Bandeja unificada multicanal
- [ ] Supervisión Key User

### Fase 5 — VENTAS + IA avanzada (semanas 14-18)
- [ ] Pipeline de leads Kanban
- [ ] Cruce servicio → venta
- [ ] Venta cruzada IA
- [ ] Reportes y KPIs por módulo

---

## VARIABLES DE ENTORNO REQUERIDAS

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Claude API
ANTHROPIC_API_KEY=

# n8n
N8N_WEBHOOK_URL=
N8N_API_KEY=

# WhatsApp (proveedor a definir: Twilio / 360dialog / Meta)
WA_API_URL=
WA_API_TOKEN=
WA_PHONE_NUMBER_ID=

# Google Maps (para links en WA de citas)
GOOGLE_MAPS_API_KEY=

# Microsoft Outlook / Graph API (para Outlook sync)
AZURE_CLIENT_ID=
AZURE_CLIENT_SECRET=
AZURE_TENANT_ID=
```

---

## CONTEXTO DEL PILOTO

- **DMS**: Autoline (exporta CSV/Excel con layout definido)
- **Fuentes de citas**: Salesforce, Seekop, ClearMechanic, Google Drive manual
- **Usuarios iniciales**: Encargada de citas, asesores de servicio, MK/Atención, gerente
- **Sucursal piloto**: Por confirmar con el concesionario
- **Marca piloto**: Por confirmar
