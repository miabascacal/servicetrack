# PRODUCT_MASTER.md
# Plataforma SaaS de Gestión de Servicio Postventa Automotriz
# Versión 1.4 — Marzo 2026

---

## 1. VISIÓN DEL PRODUCTO

Software SaaS vertical para concesionarios y grupos automotrices en México y LATAM.
Gestiona el ciclo completo de postventa: citas, taller, refacciones, ventas y comunicación con el cliente — con automatización por WhatsApp, IA transversal y sincronización con Outlook.

**Diferenciadores clave vs competencia:**
- Lee archivos de Salesforce, Seekop, ClearMechanic, Autoline y Google Drive — sin integración técnica compleja
- Flujo "encargada tiene 15 min o el bot actúa" — único en el mercado
- WA con mapa de Google Maps integrado en el mensaje de confirmación de cita
- Escalación automática en 3 niveles si el asesor no actualiza la OT
- Venta perdida con recuperación automática vinculada a CITAS
- Actividades 100% vinculadas a usuario + cliente + vehículo + empresa + Outlook
- Diseñado para México: WhatsApp-first, DMS mexicanos, horario laboral configurable

---

## 2. ARQUITECTURA DE MÓDULOS

```
┌─────────────────────────────────────┐
│              MÓDULO CITAS            │  SF · Seekop · ClearMechanic · Drive
│  Kanban · Contacto · Recordatorios  │  5 flujos
└──────────────┬──────────────────────┘
               │ Vehículo ingresa
               ▼
┌─────────────────────────────────────┐     ┌──────────────────────────┐
│           MÓDULO TALLER (PDV)        │────▶│     MÓDULO REFACCIONES   │
│  OT · Seguimiento · Piezas · CSI    │     │  Partes · PDF · Cotiz.   │
│  7 flujos (incluye Venta Perdida)   │     │  3 flujos                │
└──────────────┬──────────────────────┘     └──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────┐
│                    CRM (CORAZÓN)                         │
│  Clientes · Empresas · Vehículos · Historial            │
│  Agenda · Actividades · Outlook Sync                    │
│  3 flujos                                               │
└──────────────────────────┬──────────────────────────────┘
               │                        │
               ▼                        ▼
┌─────────────────────┐    ┌────────────────────────────┐
│   MÓDULO VENTAS     │    │     BANDEJA + IA            │
│  Pipeline · Leads   │    │  WA · FB · IG · Email      │
│  4 flujos           │    │  5 flujos                  │
└─────────────────────┘    └────────────────────────────┘
```

---

## 3. MÓDULO CRM — Corazón del sistema

### 3.1 Entidades principales
- **Clientes**: persona física o empresa, con todos sus datos de contacto y preferencias
- **Empresas**: para flotillas y negocios — un cliente puede pertenecer a una empresa
- **Vehículos**: vinculados al cliente, con historial completo de servicios
- **Actividades**: toda interacción queda registrada y vinculada

### 3.2 Flujos CRM

**F01 — Perfil único del cliente y vehículo (Driver 360)**
- Registro llega por cualquier vía: archivo, DMS, captura manual o desde otro módulo
- CRM crea un registro único. Si VIN o WA ya existe → actualiza, no duplica
- Historial del vehículo crece con cada visita: km, servicio, piezas, garantías, asesor
- Resultado: cualquier asesor ve el historial completo al abrir una nueva atención

**F02 — Agenda interna + actividades + Outlook sync**
- Se crea una actividad y se asigna al usuario correspondiente
- Tipos: Llamada · Contacto · Seguimiento · Recordatorio · Tarea · Reunión
- Bot WA al usuario asignado: "Tienes una actividad pendiente: [descripción] — [hora]"
- Actividad visible en agenda personal del usuario en CRM
- Sync automático con Outlook Calendar del usuario (bidireccional)
- Usuario marca como completada → historial del cliente actualizado
- **Aplica para TODOS los usuarios**: citas, asesores, MK, gerencia, ventas

**F03 — Lectura y procesamiento de archivos externos**
- Soporta: CSV, Excel, exportaciones de SF/Seekop/ClearMechanic/Autoline/Drive
- Valida: campos obligatorios, duplicados, formato WA, lada, VIN
- Crea si no existe, actualiza si ya existe — sin duplicados
- Datos disponibles en todos los módulos al instante

**F04 — Modelo de actividades vinculadas (arquitectura transversal)**
Toda actividad en CRM se vincula a:
1. Usuario asignado → agenda CRM + Outlook sync + WA recordatorio
2. Cliente → historial en su expediente
3. Vehículo → si aplica, trazado en historial del vehículo
4. Empresa → si es flotilla, aparece en expediente de la empresa
5. Vista resumen "Actividades del cliente" → cronológica, filtrable, exportable

---

## 4. MÓDULO CITAS

### 4.1 Fuentes de datos
- Salesforce (SF) — exportación CSV/Excel
- Seekop — exportación directa
- ClearMechanic — exportación directa
- Google Drive — archivo manual compartido
- El sistema lee CUALQUIER formato estándar sin integración técnica compleja

### 4.2 Vista Kanban — 5 columnas
1. **Pendiente de contactar** — con timer de 15 min visible
2. **Contactada** — encargada actuó antes de los 15 min
3. **Confirmada** — cliente confirmó por WA o llamada
4. **Show / Llegó** — cliente se presentó
5. **No-show** — cliente no llegó, bot activa recuperación

### 4.3 Flujos CITAS

**F01 — Lectura del archivo de citas agendadas**
- Archivo llega del Drive/SF/Seekop/ClearMechanic
- Sistema extrae: nombre cliente, WA con lada, fecha/hora, servicio, sucursal, dirección
- CRM crea o actualiza registro del cliente y vehículo
- Cita aparece en agenda CRM de la encargada como "Contacto pendiente"
- Evento creado en Outlook de la encargada automáticamente

**F02 — Contacto de confirmación (el flujo de los 15 minutos)**
- Encargada tiene 15 min desde que se asignó el contacto para actuar
- Si actúa: marca como realizado, bot NO interviene
- Si NO actúa en 15 min: bot lanza WA personalizado al cliente con:
  - Nombre del cliente, fecha y hora de la cita, nombre de la sucursal
  - Link de Google Maps con la ubicación exacta de la sucursal
- CRM registra el contacto como "realizado por sistema"
- Actividad marcada en agenda de la encargada: bot actuó por ella

**F03 — Recordatorio 24h y 2h antes**
- Bot WA 24h antes: "¿Confirmas tu cita de mañana?" con mapa de la sucursal
- Cliente responde SÍ / NO / no contesta
- Bot WA 2h antes si no confirmó aún: recordatorio urgente con mapa
- CRM actualiza estado: Confirmada / Sin confirmar / No-show pendiente

**F04 — No-show: recuperación automática**
- Encargada marca no-show con 1 clic
- Bot WA empático 2h después con 2-3 fechas disponibles
- Sin respuesta 48h: actividad en agenda de la encargada + WA a la encargada + Outlook
- CRM registra resultado: reagendado / cancelado / sin contacto

**F05 — Campaña proactiva de mantenimiento**
- Sistema analiza CRM y detecta vehículos próximos a mantenimiento (km, meses, garantía)
- Bot WA personalizado al cliente
- Sin respuesta 3 días: actividad en agenda de encargada con guión IA
- Si agenda → cita vinculada al expediente
- Si no → recordatorio automático a 30 días

---

## 5. MÓDULO TALLER (PDV)

### 5.1 Vista Kanban — 5 columnas
1. **Recibido** — vehículo en recepción
2. **Diagnóstico** — técnico evaluando
3. **En reparación** — trabajo en proceso
4. **Listo** — listo para entrega
5. **Entregado** — cliente recogió, CSI activado

### 5.2 Flujos TALLER

**F01 — Seguimiento activo del vehículo**
- Asesor recibe: fotos + checklist + promesa de entrega
- Bot WA al cliente: "Tu vehículo fue recibido" + link de seguimiento sin app ni login
- Asesor actualiza estado desde celular → bot WA automático al cliente
- Escalación automática 3 niveles si asesor no actualiza en 4h:
  - Nivel 1 (+4h): alerta al asesor
  - Nivel 2 (+2h): alerta al gerente
  - Nivel 3 (+1h): bot actúa por el asesor
- Entrega: firma digital + CSI activado automáticamente

**F02 — Pieza no disponible con fecha estimada (flujo crítico — 28% de los casos)**
- Asesor abre expediente: número de parte + proveedor + ETA
- Bot WA al cliente:
  - Con ETA: "La pieza llegará aprox. el [fecha]"
  - Sin ETA: "Seguimos coordinando con el proveedor"
  - Seguimiento cada 3 días si no hay novedad
- Pieza llega → asesor registra con 1 clic → estado: recibida
- Bot WA inmediato al cliente: "¡Buenas noticias! La pieza llegó. ¿Quieres agendar?"
  + Botón: [Sí, quiero agendar]
- Cliente toca "Sí, quiero agendar"
- Bot responde inmediatamente: "Perfecto, en breve un asesor de citas te contactará"
- CRM crea actividad automática asignada a encargada de citas:
  - Tipo: "Agendar instalación de pieza"
  - Datos: nombre cliente, WA, vehículo, número de parte, descripción
- Encargada recibe simultáneamente:
  ① WA urgente con todos los datos
  ② Email con los mismos datos
  ③ Actividad en su agenda CRM
  ④ Evento en su Outlook
- Encargada llama → agenda la cita → flujo normal de confirmación toma el control
- Si cliente NO responde: bot reintenta a 3 días, luego actividad directa a encargada

**F03 — Trabajo adicional detectado**
- Técnico/asesor detecta problema extra + toma foto
- Bot WA al cliente: foto + descripción simple + costo + botones (Autorizo / No / Más info)
- Cliente decide desde su teléfono en minutos
- Aprueba → trabajo suma a OT + nuevo tiempo estimado
- Rechaza → documentado + recordatorio automático a 30 días en CRM

**F04 — Garantía formal con la marca**
- Sistema verifica vigencia automáticamente (km + fecha de compra del CRM)
- Asesor abre expediente con foto + código de falla DTC
- Bot IA hace seguimiento cada 2 días con la marca
- WA informativo al cliente cada 3 días
- Aprobada → reparación agendada
- Rechazada → presupuesto al cliente
- Trazabilidad completa en CRM

**F05 — Diagnóstico realizado, reparación pendiente**
- Asesor registra diagnóstico
- Bot WA con resumen en lenguaje simple (no técnico)
- Sistema activa flujo según motivo: Pieza / Garantía / Decisión cliente
- Recordatorio automático a 30 / 60 / 90 días
- Nada queda en el olvido

**F06 — Venta perdida: recuperación de reparación rechazada**
- Cliente rechazó trabajo adicional → CRM registra como "Venta Perdida"
- Datos guardados: reparación, fecha, OT, cliente, vehículo
- Archivo de ventas perdidas llega al sistema (por los mismos medios que otros archivos)
- Bot WA personalizado al cliente: "[nombre], hace [X tiempo] detectamos que tu [vehículo]
  necesitaba [reparación]. Es importante atenderlo. ¿Quieres agendar?"
  + Botón: [Agendar servicio]
- Cliente toca "Agendar" → Bot responde: "Perfecto, en breve un asesor te contactará"
- CRM crea actividad en agenda de la encargada de citas:
  - Tipo: "Llamada recuperación venta perdida"
  - Descripción: cliente, vehículo, reparación pendiente
- Encargada recibe: WA urgente + Outlook + actividad en CRM
- Encargada llama → agenda cita → flujo normal toma el control
- Si cliente no responde: bot reintenta a 3 días, luego actividad directa
- Estados: detectada → registrada → contacto_enviado → cliente_interesado → cita_agendada → cerrada

**F07 — CSI post-servicio (48h después)**
- Archivo post-servicio llega al sistema: nombre, WA, OT, asesor, condición del cliente
- Sistema evalúa condición de cada cliente:
  - Cliente feliz → bot WA automático: "¿Nos dejarías una reseña?" + link Google
  - Cliente no feliz → actividad en agenda de MK/Atención:
    "Llamar a [nombre] · OT #[número] · Motivo: cliente insatisfecho"
    + WA urgente al agente MK
    + Evento en Outlook del agente MK
- Agente MK realiza la llamada → marca actividad como realizada → notas en CRM
- Ningún cliente insatisfecho queda sin contacto
- KPIs: CSI promedio, reseñas Google generadas, actividades MK realizadas

---

## 6. MÓDULO REFACCIONES

**F01 — Maestro de partes inteligente**
- Asesor busca número de parte en el sistema
- Sistema busca primero en maestro DMS (Autoline)
- Si no encuentra → scraping automático del portal de la marca:
  imagen OEM + número + precio + disponibilidad
- Todo en segundos, sin salir del sistema

**F02 — Cotización PDF con imagen OEM**
- Asesor genera cotización con 1 clic
- Sistema genera PDF: foto OEM + número de parte + precio + vigencia + logo concesionario
- Cliente recibe PDF por WA
- Sistema detecta si el cliente lo abrió (tracking de apertura)
- Asesor sabe si fue leída

**F03 — Seguimiento de presupuesto pendiente**
- Bot WA 24h: "¿Pudiste revisar la cotización?"
- Bot WA 48h: segundo intento con mensaje diferente
- Sin respuesta 72h: actividad en agenda del asesor + WA recordatorio + Outlook
- Aprueba → orden de pedido
- Rechaza → recordatorio automático a 30 días en CRM

---

## 7. MÓDULO VENTAS

**F01 — Captación de lead**
- Lead llega por WA, FB, IG, o formulario web
- Bot IA responde en <60 segundos y califica la necesidad
- CRM crea lead con: fuente, canal, necesidad, datos de contacto
- Asigna automáticamente al asesor según reglas definidas
- Asesor recibe WA de notificación + actividad en agenda

**F02 — Seguimiento del pipeline**
- Vista Kanban: Nuevo → Contactado → Cotizado → Negociando → Cerrado
- CRM registra automáticamente cada interacción
- Bot alerta si el asesor lleva +X horas sin actualizar el lead

**F03 — Cruce servicio → oportunidad de venta nueva**
- IA detecta en CRM: vehículo >4 años o alto historial de servicio
- Asesor de ventas recibe sugerencia con historial del cliente
- Si asesor aprueba: bot WA con oferta de renovación

**F04 — Actividades y recordatorios con Outlook sync**
- Asesor o sistema crea actividad de seguimiento
- Bot WA recordatorio antes de la actividad
- Sync con Outlook del asesor de ventas
- Actividad marcada como completada → historial actualizado

---

## 8. MÓDULO BANDEJA + IA

**F01 — Conversación entrante multicanal**
- Cliente escribe por WA / FB / IG / Email
- Llega a la bandeja unificada vinculada al expediente en CRM
- Asesor responde desde un solo lugar con historial visible
- Conversación registrada en CRM

**F02 — Escalación automática 3 niveles**
- 4h sin actualizar OT → Nivel 1: alerta al asesor
- +2h sin acción → Nivel 2: alerta al gerente
- +1h más → Nivel 3: bot actúa por el asesor (WA con último estado)
- Todo registrado en CRM

**F03 — Supervisión del Key User / Gerente**
- Vista global de todas las conversaciones de todos los asesores
- KPI: tiempo sin respuesta por asesor y canal
- Gerente puede intervenir directamente
- Auditoría permanente exportable

**F04 — Transferencia entre asesores**
- Gerente selecciona conversaciones del asesor ausente
- Nuevo asesor ve historial completo + nota de contexto
- Cliente no nota el cambio
- Registro de transferencia en CRM

**F05 — Venta cruzada inteligente + alerta garantía**
- IA analiza historial: km, modelo, año, servicios anteriores
- Asesor recibe sugerencia en pantalla al atender
- Bot WA post-servicio con oferta personalizada si no compró
- IA mejora sugerencias con cada visita

---

## 9. IA TRANSVERSAL

La IA opera en todos los módulos con las siguientes capacidades:

1. **Clasificación de mensajes entrantes** — detecta intención: cita, queja, consulta, venta
2. **Generación de WA personalizados** — usa nombre, vehículo, historial del cliente
3. **Sugerencias de venta cruzada** — basadas en km, modelo y servicios anteriores
4. **Guiones de llamada** — para BDC y encargada de citas según el perfil del cliente
5. **CSI inteligente** — clasifica clientes como feliz/no feliz y activa el flujo correcto
6. **Control de horario** — 8:00 AM – 7:30 PM, mensajes fuera de horario se encolan
7. **Escalación automática** — 3 niveles según tiempo sin actualización

---

## 10. ARQUITECTURA DE ACTIVIDADES (Regla universal del CRM)

Toda actividad en CRM, sin importar qué módulo la genera, se vincula a:

```
Actividad {
  id: uuid
  tipo: llamada | contacto | seguimiento | tarea | reunion | recordatorio | cita | cotizacion
  titulo: string
  descripcion: string
  fecha_programada: timestamptz
  fecha_realizada: timestamptz | null
  estado: pendiente | en_proceso | realizada | cancelada
  resultado: string | null
  notas: string | null
  prioridad: normal | alta | urgente

  -- Vínculos obligatorios
  usuario_asignado_id: FK → usuarios
  cliente_id: FK → clientes
  
  -- Vínculos opcionales (según contexto)
  vehiculo_id: FK → vehiculos | null
  empresa_id: FK → empresas | null
  ot_id: FK → ordenes_trabajo | null
  cita_id: FK → citas | null
  
  -- Notificaciones y sync
  outlook_event_id: string | null
  wa_enviado: boolean
  email_enviado: boolean
  
  -- Auditoría
  creada_por_id: FK → usuarios
  modulo_origen: crm | citas | taller | refacciones | ventas | bandeja | ia
  creada_at: timestamptz
}
```

**Vista "Actividades del cliente":**
- Cronológica, todas las interacciones del cliente en un solo lugar
- Filtrable por: tipo, usuario, fecha, módulo de origen
- Exportable para reportes
- Incluye: llamadas, WA, citas, OTs, cotizaciones, resultados de CSI

---

## 11. LAYOUT DE IMPORTACIÓN (campos mínimos para el piloto)

### Citas (desde SF / Seekop / ClearMechanic / Drive)
```
nombre_cliente, whatsapp (con lada), fecha_cita, hora_cita,
tipo_servicio, sucursal, vin (opcional), modelo_vehiculo (opcional)
```

### OTs / Taller (desde Autoline)
```
numero_ot, vin, nombre_cliente, whatsapp, numero_parte,
descripcion_pieza, fecha_pedido, eta, asesor_asignado
```

### Venta Perdida (layout externo)
```
numero_ot_origen, nombre_cliente, whatsapp, vin, 
descripcion_reparacion, monto_rechazado, fecha_rechazo, asesor
```

### CSI Post-servicio (48h después de salida)
```
nombre_cliente, whatsapp, numero_ot, asesor, 
condicion: feliz | no_feliz, fecha_salida
```

---

## 12. MODELO DE NEGOCIO Y PRECIOS

### Planes (orientativos — MXN/mes por sucursal)
| Plan | Módulos | Precio |
|------|---------|--------|
| Arranque | CRM + CITAS | $4,500–$6,000 |
| Servicio | + TALLER + REFACCIONES | $8,000–$12,000 |
| Completo | Todos los módulos | $14,000–$18,000 |
| Empresa/Grupo | Multi-sucursal + VENTAS | A negociar |

### Piloto
- Duración: 3 meses
- Costo: simbólico o sin costo a cambio de: feedback, caso de éxito, reseña
- DMS: Autoline confirmado
- Horario bot: 8:00 AM – 7:30 PM confirmado

### Decisiones pendientes para el piloto
- [ ] Nombre del producto
- [ ] Usuarios y roles exactos
- [ ] Precio final del piloto
- [ ] Reunión de validación con el concesionario

---

## 13. DIFERENCIADORES VS COMPETENCIA

| Capacidad | Nuestro sistema | GoHighLevel | ClearMechanic | Salesforce |
|-----------|----------------|-------------|----------------|------------|
| Lee archivos Drive/SF/Seekop | ✅ | ❌ | ❌ | ❌ |
| 15 min o bot actúa | ✅ | ❌ | ❌ | ❌ |
| Mapa en WA de confirmación | ✅ | ❌ | ❌ | ❌ |
| Historial del vehículo (Driver 360) | ✅ | ❌ | Parcial | ✅ |
| Venta perdida → recuperación auto | ✅ | ❌ | ❌ | ❌ |
| Escalación 3 niveles automática | ✅ | Parcial | ❌ | Parcial |
| Actividades vinculadas + Outlook | ✅ | Parcial | ❌ | ✅ |
| DMS automotriz mexicano | ✅ Autoline | ❌ | Parcial | Parcial |
| WhatsApp-first | ✅ | Parcial (SMS) | ❌ | ❌ |
| Precio accesible LATAM | ✅ | $97-497 USD | Alto | Muy alto |

